import numpy
import torch
import torch.nn as nn


class SpaBlock(nn.Module):
    def __init__(self, nc):
        super(SpaBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(nc,nc,3,1,1),
            nn.LeakyReLU(0.1,inplace=True),
            nn.Conv2d(nc, nc, 3, 1, 1),
            nn.LeakyReLU(0.1, inplace=True))

    def forward(self, x):
        return x+self.block(x)

class FreBlock(nn.Module):
    def __init__(self, nc):
        super(FreBlock, self).__init__()
        self.fpre = nn.Conv2d(nc, nc, 1, 1, 0)
        self.fpre1 = nn.Sequential(nn.Conv2d(nc, nc, 1, 1, 0),
                                   nn.BatchNorm2d(nc, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
                                   nn.ReLU(inplace=True))
        self.process1 = nn.Sequential(
            nn.Conv2d(nc, nc, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=False),
            nn.Conv2d(nc, nc, 1, 1, 0))
        self.process2 = nn.Sequential(
            nn.Conv2d(nc, nc, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=False),
            nn.Conv2d(nc, nc, 1, 1, 0))
        self.p1 = nn.Conv2d(nc,nc,1,1,0)
        self.p2 = nn.LeakyReLU(0.1, inplace=True)
        self.conv1 = nn.Sequential(
            nn.Conv2d(nc, nc,
                    kernel_size=1, groups=1, bias=False),
            nn.BatchNorm2d(nc),
            nn.ReLU(inplace=True)
        )
        self.bn = torch.nn.BatchNorm2d(nc)
        self.relu = torch.nn.ReLU(inplace=True)

    def forward(self, x):
        _, _, H, W = x.shape
        # x_freq1 = torch.fft.rfft2(x, norm='backward')
        x1 = self.relu(self.bn(self.fpre(x)) )
        x_freq = torch.fft.rfft2(x1, norm='backward')
        mag = torch.abs(x_freq)
        pha = torch.angle(x_freq)
        mag = self.process1(mag)
        pha = self.process2(pha)
        real = mag * torch.cos(pha)
        imag = mag * torch.sin(pha)
        real = self.relu(self.bn(real))
        imag = self.relu(self.bn(imag))
        x_out = torch.complex(real, imag)
        x1_out = torch.fft.irfft2(x_out, s=[H, W], norm='backward')

        return x1_out + x

class ProcessBlock(nn.Module):
    def __init__(self, in_nc, spatial = True):
        super(ProcessBlock,self).__init__()
        self.spatial = spatial
        self.spatial_process = SpaBlock(in_nc) if spatial else nn.Identity()
        self.frequency_process = FreBlock(in_nc)
        self.cat = nn.Conv2d(2*in_nc,in_nc,1,1,0) if spatial else nn.Conv2d(in_nc,in_nc,1,1,0)

    def forward(self, x):
        # x_freq = torch.fft.rfft2(x, norm='backward')
        xori = x
        x_freq = self.frequency_process(x)
        x_freq = torch.nan_to_num(x_freq, nan=1e-5, posinf=1e-5, neginf=1e-5)
        x_spatial = self.spatial_process(x)
        xcat = torch.cat([x_spatial,x_freq],1)
        x_out = self.cat(xcat) if self.spatial else self.cat(x_freq)

        return x_out+xori
        # return xori

class SFNet(nn.Module):

    def __init__(self, nc,n=1):
        super(SFNet,self).__init__()

        self.conv1 = ProcessBlock(nc,spatial=False)
        self.conv2 = ProcessBlock(nc,spatial=False)
        self.conv3 = ProcessBlock(nc,spatial=False)
        self.conv4 = ProcessBlock(nc,spatial=False)
        self.conv5 = ProcessBlock(nc,spatial=False)

    def forward(self, x):
        x_ori = x
        x1 = self.conv1(x)
        x2 = self.conv2(x1)
        x3 = self.conv3(x2)
        x4 = self.conv4(x3)
        x5 = self.conv5(x4)
        xout = x_ori + x5
        return xout

class AmplitudeNet_skip(nn.Module):
    def __init__(self, nc,n=1):
        super(AmplitudeNet_skip,self).__init__()

        self.conv0 = nn.Sequential(
            nn.Conv2d(1, nc, 1, 1, 0),
            ProcessBlock(nc),
        )
        self.conv1 = ProcessBlock(nc)
        self.conv2 = ProcessBlock(nc)
        self.conv3 = ProcessBlock(nc)
        self.conv4 = nn.Sequential(
            ProcessBlock(nc * 2),
            nn.Conv2d(nc * 2, nc, 1, 1, 0),
        )
        self.conv5 = nn.Sequential(
            ProcessBlock(nc * 2),
            nn.Conv2d(nc * 2, nc, 1, 1, 0),
        )
        self.convout = nn.Sequential(
            ProcessBlock(nc * 2),
            nn.Conv2d(nc * 2, 3, 1, 1, 0),
        )
        self.conv = nn.Sequential(
            nn.Conv2d(1, 1, 1, 1, 0),
            nn.BatchNorm2d(1),
            nn.ReLU(inplace=True)
        )
        self.fpre = nn.Conv2d(1,nc,1,1,0)
        self.conv_1 = nn.Sequential(
            nn.Conv2d(1, nc, 1, 1, 0),
            nn.BatchNorm2d(nc, eps = 1e-05, momentum = 0.1, affine = True, track_running_stats = True),
            nn.ReLU(inplace=True),
        )
    def forward(self, x):
        # x_freq = torch.fft.rfft2(x, norm='backward')
        x = self.conv0(x)
        x1 = self.conv1(x)
        x2 = self.conv2(x1)
        x3 = self.conv3(x2)
        x4 = self.conv4(torch.cat((x2, x3), dim=1))
        x5 = self.conv5(torch.cat((x1, x4), dim=1))
        xout = self.convout(torch.cat((x, x5), dim=1))

        return xout
